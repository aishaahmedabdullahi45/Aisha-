function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,0,300);
  //Drawing of ellipse shape
  ellipse(250,140,100,50);
  fill(2);
  // Drawing of triangle
  triangle(300,56,78,80,20,20,);
  fill(260,10,10);
}